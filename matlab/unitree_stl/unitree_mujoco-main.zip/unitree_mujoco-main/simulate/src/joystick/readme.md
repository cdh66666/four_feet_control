This joystick tool is based on https://github.com/drewnoakes/joystick

```
sudo apt install joystick
```