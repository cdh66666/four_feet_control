
## STL format:
### Instructions:
* The four hips are different, but you can get all four hips from only one hip by rotating it. `hip` means left-front hip.
* The left and right thigh are different. `thigh` means left thigh, and `thigh_mirror` means right thigh.
* The four calfs are all the same.
